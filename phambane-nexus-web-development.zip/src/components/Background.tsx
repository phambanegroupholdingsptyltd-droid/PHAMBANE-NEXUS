import { useEffect, useRef } from 'react';

export default function Background() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrameId: number;
    let nodes: Array<{
      x: number; y: number;
      vx: number; vy: number;
      size: number; opacity: number;
      pulseSpeed: number; pulseOffset: number;
    }> = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createNodes = () => {
      nodes = [];
      const count = Math.floor((window.innerWidth * window.innerHeight) / 28000);
      for (let i = 0; i < count; i++) {
        nodes.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          size: Math.random() * 2 + 1,
          opacity: Math.random() * 0.5 + 0.1,
          pulseSpeed: Math.random() * 0.02 + 0.005,
          pulseOffset: Math.random() * Math.PI * 2,
        });
      }
    };

    let frame = 0;
    const draw = () => {
      frame++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxDist = 160;

          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.12;
            ctx.beginPath();
            ctx.strokeStyle = `rgba(123, 47, 190, ${alpha})`;
            ctx.lineWidth = 0.8;
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw & update nodes
      for (const node of nodes) {
        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;

        const pulse = Math.sin(frame * node.pulseSpeed + node.pulseOffset);
        const currentOpacity = node.opacity * (0.5 + 0.5 * pulse);

        ctx.beginPath();
        ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(168, 85, 247, ${currentOpacity})`;
        ctx.fill();

        // Glow effect for some nodes
        if (currentOpacity > 0.4) {
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.size * 2.5, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(168, 85, 247, ${currentOpacity * 0.15})`;
          ctx.fill();
        }
      }

      animFrameId = requestAnimationFrame(draw);
    };

    resize();
    createNodes();
    draw();

    window.addEventListener('resize', () => { resize(); createNodes(); });

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }}>
      {/* Grid background */}
      <div className="grid-bg" />

      {/* Scan line */}
      <div className="scan-line" />

      {/* Canvas for network nodes */}
      <canvas
        ref={canvasRef}
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          opacity: 0.7,
        }}
      />

      {/* Static circuit nodes */}
      {[
        { top: '15%', left: '8%', delay: '0s' },
        { top: '35%', left: '92%', delay: '0.8s' },
        { top: '70%', left: '5%', delay: '1.6s' },
        { top: '85%', left: '88%', delay: '0.4s' },
        { top: '50%', left: '50%', delay: '1.2s' },
        { top: '20%', left: '60%', delay: '2s' },
      ].map((pos, i) => (
        <div
          key={i}
          className="circuit-node"
          style={{
            top: pos.top,
            left: pos.left,
            animationDelay: pos.delay,
          }}
        />
      ))}
    </div>
  );
}

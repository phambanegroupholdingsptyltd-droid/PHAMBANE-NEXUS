interface FooterProps {
  onNavigate: (page: 'home' | 'contact') => void;
  currentPage: 'home' | 'contact';
}

export default function Footer({ onNavigate, currentPage }: FooterProps) {
  const year = new Date().getFullYear();

  const scrollToServices = () => {
    if (currentPage !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="footer" style={{ position: 'relative', zIndex: 1 }}>
      {/* Top glow line */}
      <div className="glow-line" />

      {/* Main footer content */}
      <div
        className="footer-grid"
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '60px 24px 40px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '48px',
        }}>

        {/* Brand column */}
        <div style={{ gridColumn: 'span 1' }}>
          <div style={{ marginBottom: '16px' }}>
            <span className="logo-text" style={{ fontSize: '1.1rem', display: 'block', marginBottom: '4px' }}>
              PN | PHAMBANE NEXUS
            </span>
            <span style={{
              fontFamily: "'Rajdhani', sans-serif",
              fontSize: '0.65rem',
              letterSpacing: '0.12em',
              color: 'rgba(168, 85, 247, 0.6)',
              textTransform: 'uppercase',
            }}>
              AI Automation & Digital Systems
            </span>
          </div>
          <p style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.82rem',
            color: '#555',
            lineHeight: 1.7,
            marginBottom: '20px',
          }}>
            A division of Phambane Group Holdings (Pty) Ltd. Engineering intelligent systems that deliver real operational excellence.
          </p>

          {/* Social / contact links */}
          <div style={{ display: 'flex', gap: '12px' }}>
            <a
              href="https://wa.me/27737681858"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                width: '38px', height: '38px',
                border: '1px solid rgba(123, 47, 190, 0.25)',
                borderRadius: '6px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#666',
                transition: 'all 0.3s ease',
                textDecoration: 'none',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLAnchorElement).style.borderColor = '#25D366';
                (e.currentTarget as HTMLAnchorElement).style.color = '#25D366';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLAnchorElement).style.borderColor = 'rgba(123, 47, 190, 0.25)';
                (e.currentTarget as HTMLAnchorElement).style.color = '#666';
              }}
              title="WhatsApp"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
              </svg>
            </a>
            <a
              href="mailto:phambanegroupholdingsptyltd@gmail.com"
              style={{
                width: '38px', height: '38px',
                border: '1px solid rgba(123, 47, 190, 0.25)',
                borderRadius: '6px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#666',
                transition: 'all 0.3s ease',
                textDecoration: 'none',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLAnchorElement).style.borderColor = '#A855F7';
                (e.currentTarget as HTMLAnchorElement).style.color = '#A855F7';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLAnchorElement).style.borderColor = 'rgba(123, 47, 190, 0.25)';
                (e.currentTarget as HTMLAnchorElement).style.color = '#666';
              }}
              title="Email"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                <polyline points="22,6 12,13 2,6"/>
              </svg>
            </a>
          </div>
        </div>

        {/* Navigation */}
        <div>
          <h4 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: '0.65rem',
            letterSpacing: '0.2em',
            color: '#A855F7',
            textTransform: 'uppercase',
            marginBottom: '20px',
          }}>
            Navigation
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {[
              { label: 'Home', action: () => { onNavigate('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); } },
              { label: 'Services', action: scrollToServices },
              { label: 'Contact Us', action: () => { onNavigate('contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); } },
              { label: 'Book Discovery Call', href: 'https://wa.me/27737681858' },
            ].map((item, i) => (
              item.href ? (
                <a
                  key={i}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '0.85rem',
                    color: '#555',
                    textDecoration: 'none',
                    transition: 'color 0.2s',
                    width: 'fit-content',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#A855F7')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#555')}
                >
                  {item.label}
                </a>
              ) : (
                <button
                  key={i}
                  onClick={item.action}
                  style={{
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '0.85rem',
                    color: '#555',
                    textAlign: 'left',
                    padding: 0,
                    transition: 'color 0.2s',
                    width: 'fit-content',
                  }}
                  onMouseEnter={e => ((e.currentTarget as HTMLButtonElement).style.color = '#A855F7')}
                  onMouseLeave={e => ((e.currentTarget as HTMLButtonElement).style.color = '#555')}
                >
                  {item.label}
                </button>
              )
            ))}
          </div>
        </div>

        {/* Services */}
        <div>
          <h4 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: '0.65rem',
            letterSpacing: '0.2em',
            color: '#A855F7',
            textTransform: 'uppercase',
            marginBottom: '20px',
          }}>
            Services
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              'AI Chatbot Development',
              'WhatsApp Automation',
              'Conversational AI Agents',
              'Document Processing',
              'CRM & Workflow Automation',
              'Web Design & Backend Sync',
            ].map((service, i) => (
              <button
                key={i}
                onClick={scrollToServices}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '0.82rem',
                  color: '#555',
                  textAlign: 'left',
                  padding: 0,
                  transition: 'color 0.2s',
                  width: 'fit-content',
                }}
                onMouseEnter={e => ((e.currentTarget as HTMLButtonElement).style.color = '#A855F7')}
                onMouseLeave={e => ((e.currentTarget as HTMLButtonElement).style.color = '#555')}
              >
                {service}
              </button>
            ))}
          </div>
        </div>

        {/* Contact column */}
        <div>
          <h4 style={{
            fontFamily: "'Orbitron', monospace",
            fontSize: '0.65rem',
            letterSpacing: '0.2em',
            color: '#A855F7',
            textTransform: 'uppercase',
            marginBottom: '20px',
          }}>
            Contact
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <a href="https://wa.me/27737681858" target="_blank" rel="noopener noreferrer"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: '0.82rem', color: '#555', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#A855F7')}
              onMouseLeave={e => (e.currentTarget.style.color = '#555')}
            >
              +27 73 768 1858
            </a>
            <a href="mailto:phambanegroupholdingsptyltd@gmail.com"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: '0.78rem', color: '#555', textDecoration: 'none', transition: 'color 0.2s', wordBreak: 'break-all' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#A855F7')}
              onMouseLeave={e => (e.currentTarget.style.color = '#555')}
            >
              phambanegroupholdingsptyltd@gmail.com
            </a>
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '0.82rem', color: '#555' }}>
              Johannesburg, Gauteng<br />South Africa
            </span>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{
        borderTop: '1px solid rgba(123, 47, 190, 0.1)',
        padding: '20px 24px',
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '16px',
        }}>
          <p style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.75rem',
            color: '#3a3a3a',
          }}>
            © {year} Phambane Group Holdings (Pty) Ltd. All rights reserved.
          </p>

          <div style={{ display: 'flex', gap: '20px', alignItems: 'center', flexWrap: 'wrap' }}>
            {['POPIA Compliant', 'CPA Compliant', 'All pricing in ZAR'].map((item, i) => (
              <span
                key={i}
                style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontWeight: 600,
                  fontSize: '0.7rem',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: 'rgba(168, 85, 247, 0.5)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                }}
              >
                <span style={{
                  display: 'inline-block',
                  width: '5px', height: '5px',
                  borderRadius: '50%',
                  background: 'rgba(168, 85, 247, 0.4)',
                }} />
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Responsive handled via CSS classes */}
    </footer>
  );
}

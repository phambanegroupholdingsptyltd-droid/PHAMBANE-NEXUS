import { useState, useEffect } from 'react';

interface HeaderProps {
  currentPage: 'home' | 'contact';
  onNavigate: (page: 'home' | 'contact') => void;
}

export default function Header({ currentPage, onNavigate }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Lock body scroll when mobile menu open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const handleNav = (page: 'home' | 'contact') => {
    onNavigate(page);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToServices = () => {
    setMobileOpen(false);
    if (currentPage !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header className={`header ${scrolled ? 'scrolled' : ''}`} style={{ padding: '0 24px' }}>
        <div style={{
          maxWidth: '1280px',
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: '72px',
        }}>
          {/* LOGO */}
          <button
            onClick={() => handleNav('home')}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
              <span className="logo-text" style={{ fontSize: '1.1rem', lineHeight: 1 }}>
                PN | PHAMBANE NEXUS
              </span>
              <span style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontSize: '0.62rem',
                letterSpacing: '0.12em',
                color: 'rgba(168, 85, 247, 0.7)',
                textTransform: 'uppercase',
                lineHeight: 1.4,
              }}>
                AI Automation & Digital Systems
              </span>
            </div>
          </button>

          {/* DESKTOP NAV */}
          <nav style={{ display: 'flex', alignItems: 'center', gap: '36px' }} className="desktop-nav">
            <button
              onClick={() => handleNav('home')}
              className={`nav-link ${currentPage === 'home' ? 'active' : ''}`}
              style={{ background: 'none', border: 'none', cursor: 'pointer' }}
            >
              Home
            </button>
            <button
              onClick={scrollToServices}
              className="nav-link"
              style={{ background: 'none', border: 'none', cursor: 'pointer' }}
            >
              Services
            </button>
            <button
              onClick={() => handleNav('contact')}
              className={`nav-link ${currentPage === 'contact' ? 'active' : ''}`}
              style={{ background: 'none', border: 'none', cursor: 'pointer' }}
            >
              Contact
            </button>
            <a
              href="https://wa.me/27737681858"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
              style={{ padding: '10px 20px', fontSize: '0.8rem' }}
            >
              <span>Book Discovery Call</span>
            </a>
          </nav>

          {/* MOBILE HAMBURGER */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="mobile-hamburger"
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              display: 'none',
              flexDirection: 'column',
              gap: '5px',
              padding: '8px',
              zIndex: 1001,
              position: 'relative',
            }}
            aria-label="Toggle menu"
          >
            <span style={{
              display: 'block', width: '24px', height: '2px',
              background: mobileOpen ? '#A855F7' : 'white',
              transition: 'all 0.3s ease',
              transform: mobileOpen ? 'rotate(45deg) translate(5px, 5px)' : 'none',
            }} />
            <span style={{
              display: 'block', width: '24px', height: '2px',
              background: mobileOpen ? '#A855F7' : 'white',
              transition: 'all 0.3s ease',
              opacity: mobileOpen ? 0 : 1,
            }} />
            <span style={{
              display: 'block', width: '24px', height: '2px',
              background: mobileOpen ? '#A855F7' : 'white',
              transition: 'all 0.3s ease',
              transform: mobileOpen ? 'rotate(-45deg) translate(5px, -5px)' : 'none',
            }} />
          </button>
        </div>

        <style>{`
          @media (max-width: 768px) {
            .desktop-nav { display: none !important; }
            .mobile-hamburger { display: flex !important; }
          }
        `}</style>
      </header>

      {/* MOBILE MENU */}
      <div className={`mobile-menu ${mobileOpen ? 'open' : ''}`}>
        {/* Close button */}
        <button
          onClick={() => setMobileOpen(false)}
          style={{
            position: 'absolute', top: '24px', right: '24px',
            background: 'none', border: 'none', cursor: 'pointer',
            color: 'white', fontSize: '1.5rem', zIndex: 1001,
          }}
        >✕</button>

        <div style={{ marginBottom: '20px', textAlign: 'center' }}>
          <span className="logo-text" style={{ fontSize: '1.2rem' }}>PN | PHAMBANE NEXUS</span>
        </div>

        <div className="glow-line" style={{ width: '120px', marginBottom: '20px' }} />

        <button onClick={() => handleNav('home')} className="mobile-nav-link" style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          HOME
        </button>
        <button onClick={scrollToServices} className="mobile-nav-link" style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          SERVICES
        </button>
        <button onClick={() => handleNav('contact')} className="mobile-nav-link" style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          CONTACT
        </button>

        <div className="glow-line" style={{ width: '120px', marginTop: '10px' }} />

        <a
          href="https://wa.me/27737681858"
          target="_blank"
          rel="noopener noreferrer"
          className="btn-primary"
          style={{ marginTop: '10px' }}
          onClick={() => setMobileOpen(false)}
        >
          <span>Book Discovery Call</span>
        </a>
      </div>
    </>
  );
}

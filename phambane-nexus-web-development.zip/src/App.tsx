import { useState } from 'react';
import Background from './components/Background';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ContactPage from './pages/ContactPage';

type Page = 'home' | 'contact';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0A0A0A',
      position: 'relative',
    }}>
      {/* Animated Background */}
      <Background />

      {/* Header */}
      <Header currentPage={currentPage} onNavigate={handleNavigate} />

      {/* Page Content */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        {currentPage === 'home' ? (
          <HomePage onNavigate={handleNavigate} />
        ) : (
          <ContactPage />
        )}

        {/* Footer */}
        <Footer currentPage={currentPage} onNavigate={handleNavigate} />
      </div>
    </div>
  );
}

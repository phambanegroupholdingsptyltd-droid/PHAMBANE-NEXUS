import { useEffect, useRef } from 'react';

interface HomePageProps {
  onNavigate: (page: 'home' | 'contact') => void;
}

const services = [
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        <circle cx="9" cy="10" r="1" fill="#A855F7"/>
        <circle cx="12" cy="10" r="1" fill="#A855F7"/>
        <circle cx="15" cy="10" r="1" fill="#A855F7"/>
      </svg>
    ),
    title: 'AI Chatbot Development',
    desc: 'Custom intelligent chatbots trained on your business data. 24/7 customer engagement, lead capture, and support — fully automated and on-brand.',
    tag: 'NLP · GPT · Custom LLM',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
        <path d="M14.5 2.5c1.5 0 3 .5 4.5 1.5" stroke="#7B2FBE" strokeWidth="1.5"/>
        <path d="M14.5 6.5c.8 0 1.6.3 2.5.8" stroke="#7B2FBE" strokeWidth="1.5"/>
      </svg>
    ),
    title: 'WhatsApp Automation',
    desc: 'Automated WhatsApp workflows for bookings, follow-ups, order tracking, and client communication. Turn WhatsApp into a powerful business tool.',
    tag: 'WhatsApp API · Twilio · Meta',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3"/>
        <path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/>
      </svg>
    ),
    title: 'Conversational AI Agents',
    desc: 'Multi-turn AI agents that handle complex dialogues, qualify leads, schedule appointments, and resolve queries — just like a human, but faster.',
    tag: 'LangChain · RAG · Vector DB',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14,2 14,8 20,8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
        <polyline points="10,9 9,9 8,9"/>
      </svg>
    ),
    title: 'Intelligent Document Processing',
    desc: 'AI-powered extraction, classification, and processing of invoices, contracts, forms, and reports. Eliminate manual data entry and human error.',
    tag: 'OCR · NLP · ML Pipeline',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
        <line x1="8" y1="21" x2="16" y2="21"/>
        <line x1="12" y1="17" x2="12" y2="21"/>
        <path d="M6 8h4M6 11h6" stroke="#7B2FBE" strokeWidth="1.5"/>
      </svg>
    ),
    title: 'CRM & Workflow Automation',
    desc: 'Seamless CRM integration and intelligent workflow automation. Connect your tools, automate data flow, and let your team focus on revenue-generating tasks.',
    tag: 'Zapier · Make · HubSpot · Salesforce',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="2" width="20" height="8" rx="2" ry="2"/>
        <rect x="2" y="14" width="20" height="8" rx="2" ry="2"/>
        <line x1="6" y1="6" x2="6" y2="6"/>
        <line x1="6" y1="18" x2="6" y2="18"/>
      </svg>
    ),
    title: 'Web Design & Backend Sync',
    desc: 'Enterprise-grade web platforms with real-time backend integrations. Beautiful, fast, and connected to your business systems from day one.',
    tag: 'React · Node.js · API · Cloud',
  },
];

const stats = [
  { value: '98%', label: 'Client Retention Rate', suffix: '' },
  { value: '10x', label: 'Average ROI Delivered', suffix: '' },
  { value: '24/7', label: 'Automated Operations', suffix: '' },
  { value: '60%', label: 'Admin Time Reduction', suffix: '' },
];

const process = [
  { step: '01', title: 'Discovery Call', desc: 'We analyse your business processes and identify automation opportunities with measurable ROI.' },
  { step: '02', title: 'System Design', desc: 'Our engineers architect a custom solution tailored to your exact workflows and tech stack.' },
  { step: '03', title: 'Build & Integrate', desc: 'Rapid development and seamless integration with your existing tools and platforms.' },
  { step: '04', title: 'Deploy & Optimise', desc: 'Live deployment with ongoing monitoring, optimisation, and dedicated support.' },
];

export default function HomePage({ onNavigate }: HomePageProps) {
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0 });

    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    const animatedEls = document.querySelectorAll('.animate-on-scroll');
    animatedEls.forEach((el) => observerRef.current?.observe(el));

    return () => observerRef.current?.disconnect();
  }, []);

  return (
    <main style={{ position: 'relative', zIndex: 1 }}>
      {/* ===== HERO ===== */}
      <section
        className="hero-gradient"
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '120px 24px 80px',
          textAlign: 'center',
          position: 'relative',
        }}
      >
        {/* Decorative rings */}
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', pointerEvents: 'none' }}>
          <div className="pulse-ring" style={{ width: '400px', height: '400px', marginLeft: '-200px', marginTop: '-200px' }} />
          <div className="pulse-ring" style={{ width: '400px', height: '400px', marginLeft: '-200px', marginTop: '-200px', animationDelay: '0.8s' }} />
          <div className="pulse-ring" style={{ width: '400px', height: '400px', marginLeft: '-200px', marginTop: '-200px', animationDelay: '1.6s' }} />
        </div>

        <div style={{ maxWidth: '900px', position: 'relative', zIndex: 1 }}>
          {/* Badge */}
          <div className="hero-animate-1" style={{ marginBottom: '24px' }}>
            <span className="section-badge">
              A Division of Phambane Group Holdings (Pty) Ltd
            </span>
          </div>

          {/* Company name */}
          <div className="hero-animate-2" style={{ marginBottom: '12px' }}>
            <span style={{
              fontFamily: "'Rajdhani', sans-serif",
              fontWeight: 600,
              fontSize: 'clamp(0.75rem, 2vw, 0.95rem)',
              letterSpacing: '0.25em',
              color: 'rgba(168, 85, 247, 0.8)',
              textTransform: 'uppercase',
            }}>
              PHAMBANE NEXUS
            </span>
          </div>

          {/* Main tagline */}
          <h1 className="hero-title hero-animate-3" style={{
            fontSize: 'clamp(2rem, 5.5vw, 4rem)',
            marginBottom: '24px',
            color: 'white',
          }}>
            INTELLIGENT SYSTEMS.{' '}
            <span className="purple-gradient-text">REAL RESULTS.</span>{' '}
            OPERATIONAL EXCELLENCE.
          </h1>

          {/* Sub-headline */}
          <p className="hero-animate-4" style={{
            fontFamily: "'DM Sans', sans-serif",
            fontSize: 'clamp(1rem, 2.5vw, 1.2rem)',
            lineHeight: 1.7,
            color: '#A0A0A0',
            marginBottom: '48px',
            maxWidth: '680px',
            margin: '0 auto 48px',
          }}>
            We engineer elite AI automation systems that eliminate administrative
            bottlenecks and drive measurable business growth.
          </p>

          {/* CTAs */}
          <div className="hero-animate-5" style={{
            display: 'flex',
            gap: '16px',
            justifyContent: 'center',
            flexWrap: 'wrap',
            marginBottom: '80px',
          }}>
            <a
              href="https://wa.me/27737681858"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
              </svg>
              <span>Book a Free Discovery Call</span>
            </a>
            <button
              onClick={() => {
                document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-secondary"
            >
              <span>View Our Services</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </button>
          </div>

          {/* Stats */}
          <div className="hero-animate-6 hero-stats-grid" style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
            gap: '1px',
            background: 'rgba(123, 47, 190, 0.15)',
            border: '1px solid rgba(123, 47, 190, 0.15)',
            borderRadius: '12px',
            overflow: 'hidden',
            maxWidth: '700px',
            margin: '0 auto',
          }}>
            {stats.map((stat, i) => (
              <div
                key={i}
                style={{
                  padding: '28px 20px',
                  background: 'rgba(10, 10, 10, 0.8)',
                  textAlign: 'center',
                }}
              >
                <div className="stat-number">{stat.value}</div>
                <div style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontSize: '0.75rem',
                  letterSpacing: '0.08em',
                  color: '#666',
                  textTransform: 'uppercase',
                  marginTop: '4px',
                }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{
          position: 'absolute',
          bottom: '40px',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '8px',
        }}>
          <span style={{
            fontFamily: "'Rajdhani', sans-serif",
            fontSize: '0.7rem',
            letterSpacing: '0.2em',
            color: '#444',
            textTransform: 'uppercase',
          }}>Scroll</span>
          <div style={{
            width: '20px',
            height: '32px',
            border: '1px solid rgba(123, 47, 190, 0.4)',
            borderRadius: '10px',
            display: 'flex',
            justifyContent: 'center',
            padding: '4px',
          }}>
            <div style={{
              width: '3px',
              height: '8px',
              background: '#A855F7',
              borderRadius: '2px',
              animation: 'scrollDot 1.8s ease-in-out infinite',
            }} />
          </div>
          <style>{`
            @keyframes scrollDot {
              0%, 100% { transform: translateY(0); opacity: 1; }
              50% { transform: translateY(10px); opacity: 0.3; }
            }
          `}</style>
        </div>
      </section>

      {/* ===== SERVICES SECTION ===== */}
      <section id="services" style={{ padding: '100px 24px', position: 'relative' }}>
        <div className="glow-line" style={{ marginBottom: '80px' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>

          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <div className="animate-on-scroll">
              <div className="section-badge">Our Capabilities</div>
            </div>
            <h2 className="animate-on-scroll animate-delay-1" style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 'clamp(1.6rem, 4vw, 2.8rem)',
              fontWeight: 700,
              color: 'white',
              marginBottom: '16px',
              lineHeight: 1.2,
            }}>
              ENTERPRISE AI <span className="purple-text">SOLUTIONS</span>
            </h2>
            <p className="animate-on-scroll animate-delay-2" style={{
              fontFamily: "'DM Sans', sans-serif",
              color: '#777',
              fontSize: '1.05rem',
              maxWidth: '560px',
              margin: '0 auto',
              lineHeight: 1.7,
            }}>
              Six specialised service pillars engineered to transform your operations and scale your business intelligently.
            </p>
          </div>

          {/* Service Cards Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '24px',
          }}>
            {services.map((service, i) => (
              <div
                key={i}
                className={`service-card animate-on-scroll animate-delay-${(i % 3) + 1}`}
              >
                <div className="service-icon">
                  {service.icon}
                </div>
                <h3 style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontWeight: 700,
                  fontSize: '1.25rem',
                  letterSpacing: '0.05em',
                  color: 'white',
                  marginBottom: '12px',
                  position: 'relative',
                  zIndex: 1,
                }}>
                  {service.title}
                </h3>
                <p style={{
                  fontFamily: "'Inter', sans-serif",
                  color: '#777',
                  fontSize: '0.92rem',
                  lineHeight: 1.7,
                  marginBottom: '20px',
                  position: 'relative',
                  zIndex: 1,
                }}>
                  {service.desc}
                </p>
                <div style={{
                  display: 'inline-flex',
                  padding: '4px 12px',
                  background: 'rgba(123, 47, 190, 0.1)',
                  border: '1px solid rgba(123, 47, 190, 0.2)',
                  borderRadius: '100px',
                  fontFamily: "'Rajdhani', sans-serif",
                  fontSize: '0.72rem',
                  letterSpacing: '0.08em',
                  color: 'rgba(168, 85, 247, 0.8)',
                  position: 'relative',
                  zIndex: 1,
                }}>
                  {service.tag}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PROCESS SECTION ===== */}
      <section style={{ padding: '100px 24px', background: 'rgba(17, 17, 17, 0.5)', position: 'relative' }}>
        <div className="glow-line" style={{ marginBottom: '80px' }} />
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <div className="animate-on-scroll">
              <div className="section-badge">How We Work</div>
            </div>
            <h2 className="animate-on-scroll animate-delay-1" style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 'clamp(1.6rem, 4vw, 2.8rem)',
              fontWeight: 700,
              color: 'white',
              lineHeight: 1.2,
            }}>
              OUR <span className="purple-text">PROCESS</span>
            </h2>
          </div>

          <div className="process-grid" style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
            gap: '2px',
            position: 'relative',
          }}>
            {process.map((step, i) => (
              <div
                key={i}
                className={`animate-on-scroll animate-delay-${i + 1}`}
                style={{
                  padding: '40px 28px',
                  background: 'rgba(14, 14, 14, 0.9)',
                  border: '1px solid rgba(123, 47, 190, 0.1)',
                  borderRadius: '8px',
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                <div style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: '3.5rem',
                  fontWeight: 900,
                  color: 'rgba(123, 47, 190, 0.08)',
                  lineHeight: 1,
                  marginBottom: '16px',
                  letterSpacing: '-0.02em',
                }}>
                  {step.step}
                </div>
                <div style={{
                  width: '32px',
                  height: '2px',
                  background: 'linear-gradient(90deg, #7B2FBE, #A855F7)',
                  marginBottom: '16px',
                  boxShadow: '0 0 8px #A855F7',
                }} />
                <h3 style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontWeight: 700,
                  fontSize: '1.1rem',
                  letterSpacing: '0.08em',
                  color: 'white',
                  textTransform: 'uppercase',
                  marginBottom: '12px',
                }}>
                  {step.title}
                </h3>
                <p style={{
                  fontFamily: "'Inter', sans-serif",
                  color: '#666',
                  fontSize: '0.88rem',
                  lineHeight: 1.7,
                }}>
                  {step.desc}
                </p>

                {/* Connector arrow (not on last) */}
                {i < process.length - 1 && (
                  <div style={{
                    position: 'absolute',
                    right: '-14px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    width: '28px',
                    height: '28px',
                    background: '#0A0A0A',
                    border: '1px solid rgba(168, 85, 247, 0.3)',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 2,
                    color: '#A855F7',
                    fontSize: '0.8rem',
                  }}>
                    →
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CTA SECTION ===== */}
      <section style={{ padding: '100px 24px', position: 'relative' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto', textAlign: 'center' }}>
          <div
            className="animate-on-scroll"
            style={{
              background: 'linear-gradient(135deg, rgba(123, 47, 190, 0.15), rgba(168, 85, 247, 0.05))',
              border: '1px solid rgba(123, 47, 190, 0.25)',
              borderRadius: '16px',
              padding: 'clamp(40px, 8vw, 80px) clamp(24px, 6vw, 64px)',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Glow */}
            <div style={{
              position: 'absolute',
              top: '-50%',
              left: '50%',
              transform: 'translateX(-50%)',
              width: '400px',
              height: '400px',
              background: 'radial-gradient(ellipse, rgba(168, 85, 247, 0.12) 0%, transparent 70%)',
              pointerEvents: 'none',
            }} />

            <div className="section-badge" style={{ display: 'inline-flex', marginBottom: '24px' }}>
              Ready to Transform?
            </div>

            <h2 style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 'clamp(1.4rem, 4vw, 2.4rem)',
              fontWeight: 700,
              color: 'white',
              lineHeight: 1.2,
              marginBottom: '16px',
              position: 'relative',
            }}>
              START YOUR <span className="purple-gradient-text">AUTOMATION JOURNEY</span>
            </h2>

            <p style={{
              fontFamily: "'DM Sans', sans-serif",
              color: '#777',
              fontSize: '1rem',
              lineHeight: 1.7,
              marginBottom: '40px',
              position: 'relative',
            }}>
              Book a free 30-minute discovery call. We'll map your current workflow, identify automation opportunities, and show you exactly how Phambane Nexus can deliver measurable ROI.
            </p>

            <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap', position: 'relative' }}>
              <a
                href="https://wa.me/27737681858"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
                </svg>
                <span>Book a Free Discovery Call</span>
              </a>
              <button
                onClick={() => { onNavigate('contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="btn-secondary"
              >
                <span>Send Us a Message</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

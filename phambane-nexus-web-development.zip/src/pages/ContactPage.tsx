import { useEffect, useRef, useState } from 'react';

const serviceOptions = [
  'AI Chatbot Development',
  'WhatsApp Automation',
  'Conversational AI Agents',
  'Intelligent Document Processing',
  'CRM & Workflow Automation',
  'Web Design & Backend Sync',
  'Custom / Multiple Services',
];

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '', company: '', email: '', phone: '', service: '', message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0 });

    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
          }
        });
      },
      { threshold: 0.1 }
    );

    const animatedEls = document.querySelectorAll('.animate-on-scroll');
    animatedEls.forEach((el) => observerRef.current?.observe(el));

    return () => observerRef.current?.disconnect();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Build WhatsApp message from form data
    const msg = `*New Business Enquiry — Phambane Nexus*%0A%0A*Name:* ${formData.name}%0A*Company:* ${formData.company}%0A*Email:* ${formData.email}%0A*Phone:* ${formData.phone}%0A*Service of Interest:* ${formData.service}%0A%0A*Message:*%0A${formData.message}`;

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      window.open(`https://wa.me/27737681858?text=${msg}`, '_blank');
    }, 1200);
  };

  return (
    <main style={{ position: 'relative', zIndex: 1 }}>
      {/* ===== PAGE HERO ===== */}
      <section style={{
        padding: '140px 24px 80px',
        textAlign: 'center',
        background: 'radial-gradient(ellipse 80% 60% at 50% -10%, rgba(123, 47, 190, 0.2) 0%, transparent 70%)',
        position: 'relative',
      }}>
        <div style={{ maxWidth: '700px', margin: '0 auto' }}>
          <div className="hero-animate-1" style={{ marginBottom: '20px' }}>
            <span className="section-badge">Get In Touch</span>
          </div>

          <h1 className="hero-animate-2" style={{
            fontFamily: "'Orbitron', monospace",
            fontWeight: 800,
            fontSize: 'clamp(2rem, 5vw, 3.5rem)',
            color: 'white',
            lineHeight: 1.1,
            marginBottom: '20px',
          }}>
            LET'S BUILD <span className="purple-gradient-text">SOMETHING EXCEPTIONAL</span>
          </h1>

          <p className="hero-animate-3" style={{
            fontFamily: "'DM Sans', sans-serif",
            color: '#777',
            fontSize: '1.05rem',
            lineHeight: 1.7,
          }}>
            Tell us about your business and we'll show you exactly where AI automation can deliver the most impact.
          </p>
        </div>
      </section>

      {/* ===== MAIN CONTENT ===== */}
      <section style={{ padding: '0 24px 100px' }}>
        <div
          className="contact-grid"
          style={{
            maxWidth: '1100px',
            margin: '0 auto',
            display: 'grid',
            gridTemplateColumns: 'minmax(0, 1.5fr) minmax(0, 1fr)',
            gap: '40px',
            alignItems: 'start',
          }}>

          {/* ===== CONTACT FORM ===== */}
          <div
            className="animate-on-scroll"
            style={{
              background: 'rgba(14, 14, 14, 0.9)',
              border: '1px solid rgba(123, 47, 190, 0.2)',
              borderRadius: '12px',
              padding: 'clamp(28px, 5vw, 48px)',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Top accent line */}
            <div style={{
              position: 'absolute',
              top: 0, left: 0, right: 0,
              height: '2px',
              background: 'linear-gradient(90deg, transparent, #7B2FBE, #A855F7, transparent)',
              boxShadow: '0 0 10px #A855F7',
            }} />

            <div style={{ marginBottom: '32px' }}>
              <div style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: '0.7rem',
                letterSpacing: '0.2em',
                color: '#A855F7',
                textTransform: 'uppercase',
                marginBottom: '8px',
              }}>
                Initiate Contact
              </div>
              <h2 style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontWeight: 700,
                fontSize: '1.8rem',
                color: 'white',
                letterSpacing: '0.05em',
              }}>
                Send Us a Message
              </h2>
            </div>

            {submitted ? (
              <div className="form-success">
                <div style={{ fontSize: '2rem', marginBottom: '12px' }}>✓</div>
                <div style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Message Received!</div>
                <div style={{ fontSize: '0.9rem', color: '#25D366', opacity: 0.8 }}>
                  We've opened WhatsApp with your details. A consultant will be in touch within 24 hours.
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                {/* Row 1 */}
                <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label className="form-label">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="John Doe"
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label className="form-label">Company Name</label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      placeholder="Acme Corp (Pty) Ltd"
                      className="form-input"
                    />
                  </div>
                </div>

                {/* Row 2 */}
                <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label className="form-label">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="john@company.co.za"
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label className="form-label">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+27 73 768 1858"
                      className="form-input"
                    />
                  </div>
                </div>

                {/* Service Dropdown */}
                <div style={{ marginBottom: '16px' }}>
                  <label className="form-label">Service of Interest *</label>
                  <select
                    name="service"
                    required
                    value={formData.service}
                    onChange={handleChange}
                    className="form-input"
                  >
                    <option value="" disabled>Select a service...</option>
                    {serviceOptions.map((opt) => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>

                {/* Message */}
                <div style={{ marginBottom: '28px' }}>
                  <label className="form-label">Message *</label>
                  <textarea
                    name="message"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your business, current challenges, and what you're looking to automate or improve..."
                    className="form-input"
                    rows={5}
                    style={{ resize: 'vertical', minHeight: '130px' }}
                  />
                </div>

                {/* Disclaimer */}
                <p style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '0.75rem',
                  color: '#444',
                  marginBottom: '20px',
                  lineHeight: 1.6,
                }}>
                  By submitting this form, you agree to our privacy policy in accordance with POPIA. Your information will only be used to contact you regarding your enquiry.
                </p>

                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary"
                  style={{ width: '100%', justifyContent: 'center', opacity: loading ? 0.7 : 1 }}
                >
                  {loading ? (
                    <>
                      <span style={{
                        display: 'inline-block',
                        width: '16px',
                        height: '16px',
                        border: '2px solid rgba(255,255,255,0.3)',
                        borderTopColor: 'white',
                        borderRadius: '50%',
                        animation: 'spin 0.8s linear infinite',
                      }} />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                      </svg>
                      <span>Send Message</span>
                    </>
                  )}
                </button>

                <style>{`
                  @keyframes spin {
                    to { transform: rotate(360deg); }
                  }
                `}</style>
              </form>
            )}
          </div>

          {/* ===== CONTACT INFO ===== */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>

            {/* WhatsApp CTA */}
            <div
              className="animate-on-scroll slide-right"
              style={{
                background: 'linear-gradient(135deg, rgba(37, 211, 102, 0.08), rgba(18, 140, 126, 0.08))',
                border: '1px solid rgba(37, 211, 102, 0.2)',
                borderRadius: '12px',
                padding: '28px',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              <div style={{
                position: 'absolute', top: 0, left: 0, right: 0,
                height: '2px',
                background: 'linear-gradient(90deg, transparent, #25D366, transparent)',
              }} />
              <div style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontWeight: 700,
                fontSize: '0.75rem',
                letterSpacing: '0.15em',
                color: '#25D366',
                textTransform: 'uppercase',
                marginBottom: '8px',
              }}>
                Direct WhatsApp
              </div>
              <p style={{
                fontFamily: "'Inter', sans-serif",
                color: '#888',
                fontSize: '0.88rem',
                lineHeight: 1.6,
                marginBottom: '20px',
              }}>
                Chat with us directly on WhatsApp for the fastest response. Available Monday–Friday, 08:00–18:00 SAST.
              </p>
              <a
                href="https://wa.me/27737681858"
                target="_blank"
                rel="noopener noreferrer"
                className="whatsapp-btn"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
                </svg>
                +27 73 768 1858
              </a>
            </div>

            {/* Contact Details */}
            <div className="animate-on-scroll slide-right animate-delay-2">
              <div className="contact-info-card">
                <div style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: '0.65rem',
                  letterSpacing: '0.2em',
                  color: '#A855F7',
                  textTransform: 'uppercase',
                  marginBottom: '20px',
                }}>
                  Contact Details
                </div>

                {/* Email */}
                <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div style={{
                    width: '40px', height: '40px', minWidth: '40px',
                    border: '1px solid rgba(123, 47, 190, 0.3)',
                    borderRadius: '8px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: 'rgba(123, 47, 190, 0.08)',
                  }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                      <polyline points="22,6 12,13 2,6"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: '0.72rem', letterSpacing: '0.1em', color: '#555', textTransform: 'uppercase', marginBottom: '4px' }}>Email</div>
                    <a
                      href="mailto:phambanegroupholdingsptyltd@gmail.com"
                      style={{ color: '#A0A0A0', textDecoration: 'none', fontFamily: "'Inter', sans-serif", fontSize: '0.82rem', wordBreak: 'break-all', transition: 'color 0.2s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#A855F7')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#A0A0A0')}
                    >
                      phambanegroupholdingsptyltd@gmail.com
                    </a>
                  </div>
                </div>

                {/* Phone */}
                <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div style={{
                    width: '40px', height: '40px', minWidth: '40px',
                    border: '1px solid rgba(123, 47, 190, 0.3)',
                    borderRadius: '8px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: 'rgba(123, 47, 190, 0.08)',
                  }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.11 12 19.79 19.79 0 0 1 1.04 3.36 2 2 0 0 1 3 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: '0.72rem', letterSpacing: '0.1em', color: '#555', textTransform: 'uppercase', marginBottom: '4px' }}>Phone / WhatsApp</div>
                    <a
                      href="tel:+27737681858"
                      style={{ color: '#A0A0A0', textDecoration: 'none', fontFamily: "'Inter', sans-serif", fontSize: '0.88rem', transition: 'color 0.2s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#A855F7')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#A0A0A0')}
                    >
                      +27 73 768 1858
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
                  <div style={{
                    width: '40px', height: '40px', minWidth: '40px',
                    border: '1px solid rgba(123, 47, 190, 0.3)',
                    borderRadius: '8px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: 'rgba(123, 47, 190, 0.08)',
                  }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A855F7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                      <circle cx="12" cy="10" r="3"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: '0.72rem', letterSpacing: '0.1em', color: '#555', textTransform: 'uppercase', marginBottom: '4px' }}>Location</div>
                    <div style={{ color: '#A0A0A0', fontFamily: "'Inter', sans-serif", fontSize: '0.88rem', lineHeight: 1.5 }}>
                      Johannesburg, Gauteng<br />South Africa
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Business Hours */}
            <div className="animate-on-scroll slide-right animate-delay-3">
              <div className="contact-info-card">
                <div style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: '0.65rem',
                  letterSpacing: '0.2em',
                  color: '#A855F7',
                  textTransform: 'uppercase',
                  marginBottom: '16px',
                }}>
                  Business Hours
                </div>
                {[
                  { days: 'Monday – Friday', hours: '08:00 – 18:00 SAST' },
                  { days: 'Saturday', hours: '09:00 – 13:00 SAST' },
                  { days: 'Sunday & Public Holidays', hours: 'Closed' },
                ].map((item, i) => (
                  <div key={i} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '10px 0',
                    borderBottom: i < 2 ? '1px solid rgba(123, 47, 190, 0.08)' : 'none',
                  }}>
                    <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '0.82rem', color: '#888' }}>{item.days}</span>
                    <span style={{
                      fontFamily: "'Rajdhani', sans-serif",
                      fontWeight: 600,
                      fontSize: '0.82rem',
                      color: item.hours === 'Closed' ? '#444' : '#A855F7',
                    }}>{item.hours}</span>
                  </div>
                ))}
                <div style={{
                  marginTop: '16px',
                  padding: '10px 14px',
                  background: 'rgba(168, 85, 247, 0.06)',
                  border: '1px solid rgba(168, 85, 247, 0.15)',
                  borderRadius: '6px',
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '0.78rem',
                  color: '#666',
                  lineHeight: 1.5,
                }}>
                  AI systems operate 24/7. Human support available during business hours.
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Responsive handled via CSS classes */}
      </section>
    </main>
  );
}
